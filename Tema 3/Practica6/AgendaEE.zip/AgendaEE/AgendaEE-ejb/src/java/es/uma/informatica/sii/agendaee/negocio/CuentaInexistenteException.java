
package es.uma.informatica.sii.agendaee.negocio;

/**
 *
 * @author francis
 */
public class CuentaInexistenteException extends AgendaException {
    
}
